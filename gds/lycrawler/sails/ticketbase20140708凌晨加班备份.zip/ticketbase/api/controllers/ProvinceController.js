/**
 * ProvinceController
 *
 * @description :: Server-side logic for managing provinces
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

