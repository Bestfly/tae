/**
 * SceneryController
 *
 * @description :: Server-side logic for managing sceneries
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

