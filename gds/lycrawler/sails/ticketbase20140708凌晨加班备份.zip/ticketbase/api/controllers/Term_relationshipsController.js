/**
 * Term_relationshipsController
 *
 * @description :: Server-side logic for managing term_relationships
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

