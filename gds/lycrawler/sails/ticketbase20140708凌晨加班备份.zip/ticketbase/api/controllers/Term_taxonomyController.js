/**
 * Term_taxonomyController
 *
 * @description :: Server-side logic for managing term_taxonomies
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

