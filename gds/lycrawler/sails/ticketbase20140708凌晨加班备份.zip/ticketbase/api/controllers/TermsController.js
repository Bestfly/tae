/**
 * TermsController
 *
 * @description :: Server-side logic for managing terms
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

