sails generate api country
sails generate api city
sails generate api province
sails generate api division
sails generate api scenery
sails generate api terms
sails generate api term_taxonomy
sails generate api term_relationships
