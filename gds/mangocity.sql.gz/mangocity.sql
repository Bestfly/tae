-- Adminer 3.6.2 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `CountryCode` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ProvinceId` int(11) DEFAULT NULL,
  `code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cLyId` int(11) DEFAULT NULL COMMENT '保留LY城市Id',
  `cMcId` int(11) DEFAULT NULL COMMENT '保留芒果网城市Id',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `airport` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `LyId` (`cLyId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `code` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`code`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `country` (`code`, `name`, `ename`, `prefixLetter`, `createdAt`, `updatedAt`) VALUES
('CN',	'中国',	'China',	'C',	'2014-06-12 14:51:00',	'2014-06-12 14:51:00');

DROP TABLE IF EXISTS `division`;
CREATE TABLE `division` (
  `CityId` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dLyId` int(11) DEFAULT NULL COMMENT '保留LY行政区划Id',
  `dMcId` int(11) DEFAULT NULL COMMENT '保留芒果网行政区划Id',
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `LyId` (`dLyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `province`;
CREATE TABLE `province` (
  `CountryCode` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `scenery`;
CREATE TABLE `scenery` (
  `CityId` int(11) DEFAULT NULL COMMENT '关联城市表Id',
  `DivisionId` int(11) DEFAULT NULL COMMENT '关联行政区划表Id',
  `sLyId` int(11) DEFAULT NULL COMMENT '保留LY景区Id',
  `grade` tinyint(4) DEFAULT NULL COMMENT '等级,事先规则约定1,2,3,4,5,6',
  `commentCount` int(11) DEFAULT NULL,
  `questionCount` int(11) DEFAULT NULL,
  `viewCount` int(11) DEFAULT NULL,
  `blogCount` int(11) DEFAULT NULL,
  `lon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '经度',
  `lat` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '纬度',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `aliasName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `themeName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `suitherdName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `impressionName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `themeIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `suitherdIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `impressionIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `NearbySceneryIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `NearbyHotelIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `address` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `summary` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SceneryDetail` longtext COLLATE utf8_unicode_ci,
  `imgPath` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bookFlag` tinyint(4) DEFAULT NULL COMMENT '-1：暂时下线, 0：不可预订, 1：可预订',
  `ifUseCard` tinyint(1) DEFAULT NULL COMMENT '是否需要证件, 0：不需要, 1：需要',
  `LowestPrice` decimal(10,2) DEFAULT NULL COMMENT '该景点的最低价格，可能是儿童价',
  `payMode` tinyint(1) DEFAULT NULL COMMENT '1 面付, 2 在线付, 3456789预留',
  `buyNotie` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remark` longtext COLLATE utf8_unicode_ci,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sLyId` (`sLyId`),
  UNIQUE KEY `lon` (`lon`),
  UNIQUE KEY `lat` (`lat`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `address` (`address`),
  UNIQUE KEY `imgPath` (`imgPath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `term_relationships`;
CREATE TABLE `term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `term_taxonomy`;
CREATE TABLE `term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `terms`;
CREATE TABLE `terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2014-06-19 17:53:43
