return {
  ev = require'websocket.server_ev',
  copas = require'websocket.server_copas',
}
