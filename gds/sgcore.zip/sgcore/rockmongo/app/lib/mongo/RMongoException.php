<?php

class RMongoException extends MongoException {
	
}

?>