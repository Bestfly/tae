-- Adminer 3.6.2 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `CountryCode` char(2) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '国家二字码',
  `ProvinceId` int(11) unsigned DEFAULT NULL,
  `code` char(3) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '城市三字码',
  `cLyId` int(11) unsigned DEFAULT NULL,
  `cMgId` int(11) unsigned DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `airport` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `cLyId` (`cLyId`),
  UNIQUE KEY `cMgId` (`cMgId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `code` char(2) COLLATE utf8_unicode_ci NOT NULL COMMENT '国家二字码',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`code`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `division`;
CREATE TABLE `division` (
  `CityId` int(11) unsigned DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dLyId` int(11) unsigned DEFAULT NULL,
  `dMgId` int(11) unsigned DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dLyId` (`dLyId`),
  UNIQUE KEY `dMgId` (`dMgId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `province`;
CREATE TABLE `province` (
  `CountryCode` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ename` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefixLetter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `scenery`;
CREATE TABLE `scenery` (
  `CityId` int(11) unsigned DEFAULT NULL COMMENT '景点所属城市Id',
  `DivisionId` int(11) unsigned DEFAULT NULL COMMENT '景点所属行政区Id',
  `sLyId` int(11) unsigned DEFAULT NULL COMMENT '保留LY景区Id',
  `sMgId` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '对于芒果网景区Id（中英文）',
  `grade` tinyint(4) DEFAULT NULL COMMENT '景区等级',
  `commentCount` int(11) DEFAULT NULL COMMENT '评论数量',
  `questionCount` int(11) DEFAULT NULL COMMENT '问答数量',
  `viewCount` int(11) DEFAULT NULL COMMENT '浏览数量',
  `blogCount` int(11) DEFAULT NULL COMMENT '攻略数量',
  `glon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'google地图经度',
  `glat` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'google地图纬度',
  `blon` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '百度地图经度',
  `blat` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '百度地图纬度',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '景点名称',
  `aliasName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '别名',
  `NearbySceneryIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `NearbyHotelIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `NearbyCityIds` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '多个以“|”隔开',
  `address` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '地址',
  `traffic` text COLLATE utf8_unicode_ci COMMENT '交通指南信息',
  `summary` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '景点简介',
  `SceneryDetail` longtext COLLATE utf8_unicode_ci COMMENT '景点详情',
  `imgPath` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '主图',
  `bookFlag` tinyint(4) DEFAULT NULL COMMENT '-1：暂时下线, 0：不可预订, 1：可预订',
  `ifUseCard` tinyint(1) DEFAULT NULL COMMENT '是否需要证件, 0：不需要, 1：需要',
  `LowestPrice` decimal(10,2) DEFAULT NULL COMMENT '该景点的最低价格，可能是儿童价',
  `payMode` tinyint(1) DEFAULT NULL COMMENT '1 面付, 2 在线付, 3456789预留',
  `buyNotie` varchar(320) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remark` longtext COLLATE utf8_unicode_ci,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sLyId` (`sLyId`),
  UNIQUE KEY `sMgId` (`sMgId`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `address` (`address`),
  UNIQUE KEY `imgPath` (`imgPath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `term_relationships`;
CREATE TABLE `term_relationships` (
  `object_id` varchar(24) COLLATE utf8_unicode_ci NOT NULL COMMENT 'sec:Id',
  `term_order` int(11) DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `term_taxonomy_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`object_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `term_taxonomy`;
CREATE TABLE `term_taxonomy` (
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `parent` bigint(20) unsigned DEFAULT NULL,
  `count` bigint(20) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `term_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taxonomy_term_id` (`taxonomy`,`term_id`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `terms`;
CREATE TABLE `terms` (
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `term_group` bigint(10) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- 2014-06-23 15:58:39
